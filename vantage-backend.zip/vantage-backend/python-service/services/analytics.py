# ==============================================================================
# RFM (Recency, Frequency, Monetary) segmentation using pandas' quantile
# binning. Each dimension is scored 1-5 within the current customer set, then
# the combined score maps to a human-readable segment label matching the
# ones shown in the frontend dashboard (VIP, Returning, New, At Risk,
# Churned).
# ==============================================================================

from datetime import date
from typing import List

import pandas as pd

from models.schemas import CustomerRecord


def _score_label(total_score: int) -> str:
    if total_score >= 13:
        return "VIP"
    if total_score >= 10:
        return "Returning"
    if total_score >= 7:
        return "New"
    if total_score >= 4:
        return "At Risk"
    return "Churned"


def compute_rfm(customers: List[CustomerRecord]) -> dict:
    if not customers:
        return {"segments": []}

    df = pd.DataFrame([c.model_dump() for c in customers])
    today = pd.Timestamp(date.today())
    df["recency_days"] = (today - pd.to_datetime(df["last_purchase_date"])).dt.days

    # Lower recency (more recent) should score higher, so labels are reversed
    # for the recency bucket. rank(method="first") avoids duplicate-edge
    # errors from qcut when many customers share identical values.
    df["r_score"] = pd.qcut(df["recency_days"].rank(method="first"), 5, labels=[5, 4, 3, 2, 1]).astype(int)
    df["f_score"] = pd.qcut(df["frequency"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
    df["m_score"] = pd.qcut(df["monetary"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)

    df["rfm_score"] = df["r_score"] + df["f_score"] + df["m_score"]
    df["segment"] = df["rfm_score"].apply(_score_label)

    summary = (
        df.groupby("segment")
        .agg(count=("customer_id", "count"), avg_monetary=("monetary", "mean"))
        .reset_index()
    )

    return {"segments": summary.to_dict(orient="records")}
