# ==============================================================================
# Wraps Facebook Prophet for revenue/expense forecasting. Yearly seasonality
# is enabled (financial data typically has annual cycles); weekly/daily are
# disabled since the Node API aggregates transactions to daily totals, not
# finer granularity. Negative predictions are floored at zero since revenue
# and expenses can't go negative.
# ==============================================================================

from typing import List

import pandas as pd
from prophet import Prophet

from models.schemas import HistoryPoint

MODEL_VERSION = "prophet-1.1.5"


def run_forecast(history: List[HistoryPoint], horizon_days: int) -> dict:
    df = pd.DataFrame([{"ds": h.ds, "y": h.y} for h in history])

    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=False,
        daily_seasonality=False,
        interval_width=0.9,
    )
    model.fit(df)

    future = model.make_future_dataframe(periods=horizon_days)
    forecast_df = model.predict(future)

    tail = forecast_df.tail(horizon_days)
    points = [
        {
            "ds": row.ds.date(),
            "yhat": max(0.0, float(row.yhat)),
            "yhat_lower": max(0.0, float(row.yhat_lower)),
            "yhat_upper": float(row.yhat_upper),
        }
        for row in tail.itertuples()
    ]

    return {"model_version": MODEL_VERSION, "forecast": points}
