# ==============================================================================
# Vantage Analytics Service — FastAPI microservice for forecasting (Prophet)
# and customer RFM segmentation (pandas). Called by the Node backend, never
# directly by the frontend, so CORS only needs to allow the backend's origin.
# ==============================================================================

import os

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from models.schemas import ForecastRequest, ForecastResponse, RFMRequest, RFMResponse
from services.analytics import compute_rfm
from services.forecasting import run_forecast

app = FastAPI(title="Vantage Analytics Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        os.getenv("BACKEND_URL", "http://localhost:4000"),
        "http://localhost:5173",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/forecast", response_model=ForecastResponse)
def forecast(req: ForecastRequest):
    if len(req.history) < 5:
        raise HTTPException(status_code=400, detail="Need at least 5 historical data points to forecast")
    return run_forecast(req.history, req.horizon_days)


@app.post("/analytics/rfm", response_model=RFMResponse)
def rfm(req: RFMRequest):
    return compute_rfm(req.customers)
