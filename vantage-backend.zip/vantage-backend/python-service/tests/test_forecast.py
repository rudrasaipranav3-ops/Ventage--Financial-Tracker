# ==============================================================================
# Smoke tests for the analytics service. Run with: pytest tests/
# Forecast is not unit-tested here since fitting a real Prophet model in CI
# is slow; that's better covered by an integration test against a fixture.
# ==============================================================================

import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models.schemas import CustomerRecord  # noqa: E402
from services.analytics import compute_rfm  # noqa: E402


def _make_customers(n: int):
    today = date.today()
    return [
        CustomerRecord(
            customer_id=f"c{i}",
            last_purchase_date=today - timedelta(days=i * 7),
            frequency=(i % 10) + 1,
            monetary=100.0 * (i + 1),
        )
        for i in range(n)
    ]


def test_compute_rfm_returns_segments_for_enough_customers():
    result = compute_rfm(_make_customers(25))
    assert "segments" in result
    assert len(result["segments"]) > 0
    total = sum(s["count"] for s in result["segments"])
    assert total == 25


def test_compute_rfm_handles_empty_input():
    result = compute_rfm([])
    assert result == {"segments": []}
