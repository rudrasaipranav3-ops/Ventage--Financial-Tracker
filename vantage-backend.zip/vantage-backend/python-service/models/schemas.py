# ==============================================================================
# Pydantic models shared by the FastAPI routes. Keeping these separate from
# main.py makes it easy to reuse the same schemas in tests.
# ==============================================================================

from datetime import date
from typing import List

from pydantic import BaseModel


class HistoryPoint(BaseModel):
    ds: date
    y: float


class ForecastRequest(BaseModel):
    history: List[HistoryPoint]
    horizon_days: int = 90


class ForecastPoint(BaseModel):
    ds: date
    yhat: float
    yhat_lower: float
    yhat_upper: float


class ForecastResponse(BaseModel):
    model_version: str
    forecast: List[ForecastPoint]


class CustomerRecord(BaseModel):
    customer_id: str
    last_purchase_date: date
    frequency: int
    monetary: float


class RFMRequest(BaseModel):
    customers: List[CustomerRecord]


class RFMSegment(BaseModel):
    segment: str
    count: int
    avg_monetary: float


class RFMResponse(BaseModel):
    segments: List[RFMSegment]
