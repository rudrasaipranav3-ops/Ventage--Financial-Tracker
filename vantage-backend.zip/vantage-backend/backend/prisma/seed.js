// ============================================================================
// Seeds the database with a demo admin account, a product catalog, and
// twelve months of sample revenue/expense transactions across four regions.
// Run with: npm run prisma:seed
// ============================================================================

const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");

const prisma = new PrismaClient();

const PRODUCT_NAMES = [
  "Core Platform License",
  "Analytics Add-on",
  "Enterprise Bundle",
  "API Access Tier",
  "Premium Support",
  "Mobile Suite",
];

const REGIONS = ["North America", "Europe", "APAC", "LATAM"];

async function main() {
  const passwordHash = await bcrypt.hash("Password123!", 12);
  const admin = await prisma.user.upsert({
    where: { email: "admin@vantage-demo.io" },
    update: {},
    create: {
      email: "admin@vantage-demo.io",
      passwordHash,
      name: "Alex Morgan",
      role: "ADMIN",
    },
  });

  const products = [];
  for (let i = 0; i < PRODUCT_NAMES.length; i++) {
    const product = await prisma.product.upsert({
      where: { sku: `SKU-${i + 1}` },
      update: {},
      create: {
        name: PRODUCT_NAMES[i],
        sku: `SKU-${i + 1}`,
        price: 500 + i * 120,
      },
    });
    products.push(product);
  }

  const now = new Date();
  const rows = [];
  for (let m = 11; m >= 0; m--) {
    const date = new Date(now.getFullYear(), now.getMonth() - m, 15);
    for (const region of REGIONS) {
      rows.push({
        type: "REVENUE",
        amount: 200000 + Math.random() * 120000,
        currency: "USD",
        category: "Subscription",
        region,
        date,
        productId: products[Math.floor(Math.random() * products.length)].id,
      });
      rows.push({
        type: "EXPENSE",
        amount: 110000 + Math.random() * 60000,
        currency: "USD",
        category: "Operations",
        region,
        date,
      });
    }
  }
  await prisma.transaction.createMany({ data: rows });

  const segments = ["VIP", "Returning", "New", "At Risk", "Churned"];
  const customerRows = [];
  for (let i = 0; i < 40; i++) {
    const segment = segments[i % segments.length];
    customerRows.push({
      name: `Demo Customer ${i + 1}`,
      email: `customer${i + 1}@example-demo.io`,
      region: REGIONS[i % REGIONS.length],
      segment,
      lifetimeValue: 1500 + Math.random() * 20000,
      churnedAt: segment === "Churned" ? new Date(now.getFullYear(), now.getMonth() - 1, 1) : null,
    });
  }
  await prisma.customer.createMany({ data: customerRows, skipDuplicates: true });

  console.log(`Seeded admin user: ${admin.email} / Password123!`);
  console.log(`Seeded ${products.length} products, ${rows.length} transactions, ${customerRows.length} customers.`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
