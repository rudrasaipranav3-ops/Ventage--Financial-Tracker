// ============================================================================
// Mounts every feature router under its own path prefix. app.js mounts this
// whole file at /api, so the final paths are e.g. /api/revenue/summary.
// ============================================================================

const express = require("express");
const router = express.Router();

router.use("/auth", require("./auth.routes"));
router.use("/revenue", require("./revenue.routes"));
router.use("/customers", require("./customers.routes"));
router.use("/products", require("./products.routes"));
router.use("/forecast", require("./forecast.routes"));
router.use("/reports", require("./reports.routes"));
router.use("/upload", require("./upload.routes"));
router.use("/ai", require("./ai.routes"));
router.use("/users", require("./users.routes"));

module.exports = router;
