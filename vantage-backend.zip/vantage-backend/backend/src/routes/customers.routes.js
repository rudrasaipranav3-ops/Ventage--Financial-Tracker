const express = require("express");
const ctrl = require("../controllers/customers.controller");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.use(requireAuth);
router.get("/segments", ctrl.listSegments);
router.get("/top", ctrl.topByLTV);
router.get("/churn", ctrl.churnRate);

module.exports = router;
