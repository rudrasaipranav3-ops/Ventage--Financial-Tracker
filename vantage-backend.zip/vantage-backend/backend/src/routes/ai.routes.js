const express = require("express");
const ctrl = require("../controllers/ai.controller");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.use(requireAuth);
router.post("/report", ctrl.generateReport);
router.post("/ask", ctrl.askQuestion);

module.exports = router;
