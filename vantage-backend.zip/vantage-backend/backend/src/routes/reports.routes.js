const express = require("express");
const ctrl = require("../controllers/reports.controller");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/roleCheck");

const router = express.Router();

router.use(requireAuth, requireRole("ANALYST"));
router.get("/export/pdf", ctrl.exportPDF);
router.get("/export/excel", ctrl.exportExcel);

module.exports = router;
