const express = require("express");
const ctrl = require("../controllers/forecast.controller");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/roleCheck");

const router = express.Router();

router.use(requireAuth);
router.post("/", requireRole("ANALYST"), ctrl.generateForecast);
router.get("/", ctrl.listForecasts);

module.exports = router;
