const express = require("express");
const multer = require("../middleware/upload");
const ctrl = require("../controllers/upload.controller");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/roleCheck");

const router = express.Router();

router.post("/", requireAuth, requireRole("ANALYST"), multer.single("file"), ctrl.uploadFile);

module.exports = router;
