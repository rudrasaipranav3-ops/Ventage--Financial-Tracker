const express = require("express");
const ctrl = require("../controllers/products.controller");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/roleCheck");

const router = express.Router();

router.use(requireAuth);
router.get("/top", ctrl.topProducts);
router.get("/", ctrl.list);
router.post("/", requireRole("ANALYST"), ctrl.create);

module.exports = router;
