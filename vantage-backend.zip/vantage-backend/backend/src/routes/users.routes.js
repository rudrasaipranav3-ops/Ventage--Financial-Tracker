const express = require("express");
const ctrl = require("../controllers/users.controller");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/roleCheck");

const router = express.Router();

router.use(requireAuth, requireRole("ADMIN"));
router.get("/", ctrl.listUsers);
router.patch("/:id/role", ctrl.updateRole);

module.exports = router;
