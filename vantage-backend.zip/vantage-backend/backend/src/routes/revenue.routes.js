const express = require("express");
const ctrl = require("../controllers/revenue.controller");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/roleCheck");

const router = express.Router();

router.use(requireAuth);
router.get("/summary", ctrl.getSummary);
router.get("/trend", ctrl.getTrend);
router.get("/by-region", ctrl.getByRegion);
router.get("/", ctrl.list);
router.post("/", requireRole("ANALYST"), ctrl.create);

module.exports = router;
