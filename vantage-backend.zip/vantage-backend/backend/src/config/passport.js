// ============================================================================
// Google OAuth 2.0 strategy. On first login for a Google account we create a
// User record with role VIEWER; an existing password account with the same
// email is linked to the Google ID rather than duplicated.
// ============================================================================

const passport = require("passport");
const { Strategy: GoogleStrategy } = require("passport-google-oauth20");
const env = require("./env");
const prisma = require("./prisma");

passport.use(
  new GoogleStrategy(
    {
      clientID: env.GOOGLE_CLIENT_ID,
      clientSecret: env.GOOGLE_CLIENT_SECRET,
      callbackURL: env.GOOGLE_CALLBACK_URL,
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        const email = profile.emails && profile.emails[0] && profile.emails[0].value;
        if (!email) return done(new Error("Google account has no public email"));

        let user = await prisma.user.findUnique({ where: { googleId: profile.id } });

        if (!user) {
          user = await prisma.user.findUnique({ where: { email } });
        }

        if (!user) {
          user = await prisma.user.create({
            data: {
              email,
              googleId: profile.id,
              name: profile.displayName || email.split("@")[0],
              avatarUrl: profile.photos && profile.photos[0] ? profile.photos[0].value : null,
              role: "VIEWER",
            },
          });
        } else if (!user.googleId) {
          user = await prisma.user.update({
            where: { id: user.id },
            data: { googleId: profile.id },
          });
        }

        return done(null, user);
      } catch (err) {
        return done(err);
      }
    }
  )
);

// Sessions are not used — auth is stateless JWT — so no serialize/deserialize
// user is required. Routes call passport.authenticate(..., { session: false }).

module.exports = passport;
