// ============================================================================
// A single shared PrismaClient instance. Reusing one client (rather than
// `new PrismaClient()` in every file) avoids exhausting Postgres connections,
// and the global cache prevents duplicate clients from hot-reload in dev.
// ============================================================================

const { PrismaClient } = require("@prisma/client");

const prisma = global.__vantagePrisma || new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  global.__vantagePrisma = prisma;
}

module.exports = prisma;
