// ============================================================================
// Process entrypoint. Kept separate from app.js so tests can import the app
// without opening a network port, and so unhandled-rejection handling has a
// server reference to close gracefully.
// ============================================================================

const app = require("./app");
const env = require("./config/env");

const server = app.listen(env.PORT, () => {
  console.log(`Vantage API listening on port ${env.PORT} [${env.NODE_ENV}]`);
});

process.on("unhandledRejection", (err) => {
  console.error("Unhandled promise rejection:", err);
  server.close(() => process.exit(1));
});

process.on("SIGTERM", () => {
  console.log("SIGTERM received, shutting down gracefully");
  server.close(() => process.exit(0));
});
