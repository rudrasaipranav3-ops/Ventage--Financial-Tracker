// ============================================================================
// Provider-agnostic AI layer. The active provider is chosen per-request (or
// falls back to env.AI_PROVIDER) so the frontend can offer a provider picker
// without any other code changing. Add a new provider by writing a function
// with the same (prompt, system) -> Promise<string> shape and registering it
// in PROVIDERS below.
// ============================================================================

const axios = require("axios");
const env = require("../config/env");

async function callOpenAI(prompt, system) {
  const { data } = await axios.post(
    "https://api.openai.com/v1/chat/completions",
    {
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: system },
        { role: "user", content: prompt },
      ],
    },
    { headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" } }
  );
  return data.choices[0].message.content;
}

async function callGemini(prompt, system) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${env.GEMINI_API_KEY}`;
  const { data } = await axios.post(
    url,
    { contents: [{ parts: [{ text: `${system}\n\n${prompt}` }] }] },
    { headers: { "Content-Type": "application/json" } }
  );
  const parts = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
  return parts && parts[0] ? parts[0].text : "";
}

async function callClaude(prompt, system) {
  const { data } = await axios.post(
    "https://api.anthropic.com/v1/messages",
    {
      model: "claude-sonnet-4-6",
      max_tokens: 1400,
      system,
      messages: [{ role: "user", content: prompt }],
    },
    {
      headers: {
        "x-api-key": env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
    }
  );
  return (data.content || [])
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("\n");
}

const PROVIDERS = { openai: callOpenAI, gemini: callGemini, claude: callClaude };

async function generateInsight(prompt, system, provider) {
  const key = provider || env.AI_PROVIDER;
  const fn = PROVIDERS[key];
  if (!fn) throw new Error(`Unknown AI provider: ${key}. Expected one of: ${Object.keys(PROVIDERS).join(", ")}`);
  return fn(prompt, system);
}

module.exports = { generateInsight, PROVIDERS };
