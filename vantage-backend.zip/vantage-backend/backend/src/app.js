// ============================================================================
// Express application setup: security headers, CORS, JSON parsing, request
// logging, rate limiting, and the mounted API router. Exported (not started)
// so tests can import it without binding a port — server.js does the listen.
// ============================================================================

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");

const passport = require("./config/passport");
const env = require("./config/env");
const routes = require("./routes");
const { notFound, errorHandler } = require("./middleware/errorHandler");

const app = express();

app.use(helmet());
app.use(cors({ origin: env.FRONTEND_URL, credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(morgan(env.NODE_ENV === "production" ? "combined" : "dev"));
app.use(passport.initialize());

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300 });
app.use("/api", apiLimiter);

app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString(), env: env.NODE_ENV });
});

app.use("/api", routes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
