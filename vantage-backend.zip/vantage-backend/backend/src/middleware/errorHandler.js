// ============================================================================
// Centralized 404 + error handling. Keeping this in one place means every
// route can just `throw` or reject its promise (via asyncHandler) instead of
// building its own try/catch response formatting.
// ============================================================================

function notFound(req, res) {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  console.error(err);
  const status = err.status || 500;
  res.status(status).json({
    error: err.publicMessage || "Internal server error",
    ...(process.env.NODE_ENV !== "production" ? { detail: err.message } : {}),
  });
}

module.exports = { notFound, errorHandler };
