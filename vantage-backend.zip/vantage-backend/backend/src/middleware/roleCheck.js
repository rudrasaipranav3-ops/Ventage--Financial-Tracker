// ============================================================================
// Role-based access control. Roles form a simple hierarchy — requireRole
// ("ANALYST") also allows MANAGER and ADMIN, but blocks VIEWER. Use after
// requireAuth so req.user is already populated.
// ============================================================================

const ROLE_RANK = { VIEWER: 0, ANALYST: 1, MANAGER: 2, ADMIN: 3 };

function requireRole(minRole) {
  return function checkRole(req, res, next) {
    const userRank = ROLE_RANK[req.user && req.user.role];
    const requiredRank = ROLE_RANK[minRole];

    if (userRank === undefined || requiredRank === undefined || userRank < requiredRank) {
      return res.status(403).json({ error: `This action requires the ${minRole} role or higher` });
    }
    next();
  };
}

module.exports = { requireRole };
