// ============================================================================
// Multer configuration for CSV/Excel dataset uploads. Files are kept in
// memory (not written to disk) since they're parsed immediately and the
// resulting rows are what gets persisted, not the raw file.
// ============================================================================

const multer = require("multer");

const ALLOWED_EXTENSIONS = [".csv", ".xlsx", ".xls"];

const storage = multer.memoryStorage();

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
  fileFilter: (req, file, cb) => {
    const ext = file.originalname.slice(file.originalname.lastIndexOf(".")).toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return cb(new Error("Only CSV and Excel files are allowed"));
    }
    cb(null, true);
  },
});

module.exports = upload;
