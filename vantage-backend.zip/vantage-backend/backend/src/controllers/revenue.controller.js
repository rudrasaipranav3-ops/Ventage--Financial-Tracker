// ============================================================================
// Revenue & expense analytics. All endpoints accept optional query filters:
// from, to (ISO dates), region, department, businessUnit — mirroring the
// global filter bar in the frontend dashboard.
// ============================================================================

const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

function buildWhere(query, type) {
  const where = { type };
  if (query.from || query.to) {
    where.date = {};
    if (query.from) where.date.gte = new Date(query.from);
    if (query.to) where.date.lte = new Date(query.to);
  }
  if (query.region && query.region !== "All") where.region = query.region;
  if (query.department) where.department = query.department;
  if (query.businessUnit) where.businessUnit = query.businessUnit;
  return where;
}

const getSummary = asyncHandler(async (req, res) => {
  const revenueWhere = buildWhere(req.query, "REVENUE");
  const expenseWhere = buildWhere(req.query, "EXPENSE");

  const [revenueAgg, expenseAgg] = await Promise.all([
    prisma.transaction.aggregate({ where: revenueWhere, _sum: { amount: true }, _count: true }),
    prisma.transaction.aggregate({ where: expenseWhere, _sum: { amount: true } }),
  ]);

  const totalRevenue = Number(revenueAgg._sum.amount || 0);
  const totalExpenses = Number(expenseAgg._sum.amount || 0);
  const profit = totalRevenue - totalExpenses;
  const netMargin = totalRevenue === 0 ? 0 : (profit / totalRevenue) * 100;

  res.json({
    totalRevenue,
    totalExpenses,
    profit,
    netMargin: +netMargin.toFixed(2),
    transactionCount: revenueAgg._count,
  });
});

const getTrend = asyncHandler(async (req, res) => {
  // date_trunc requires raw SQL — Prisma's groupBy can't bucket by month.
  const from = req.query.from ? new Date(req.query.from) : new Date("2000-01-01");
  const to = req.query.to ? new Date(req.query.to) : new Date("2100-01-01");

  const rows = await prisma.$queryRaw`
    SELECT date_trunc('month', date) AS month,
           SUM(CASE WHEN type = 'REVENUE' THEN amount ELSE 0 END) AS revenue,
           SUM(CASE WHEN type = 'EXPENSE' THEN amount ELSE 0 END) AS expenses
    FROM transactions
    WHERE date >= ${from} AND date <= ${to}
    GROUP BY 1
    ORDER BY 1 ASC;
  `;

  const trend = rows.map((r) => ({
    month: r.month,
    revenue: Number(r.revenue),
    expenses: Number(r.expenses),
    profit: Number(r.revenue) - Number(r.expenses),
  }));

  res.json({ trend });
});

const getByRegion = asyncHandler(async (req, res) => {
  const grouped = await prisma.transaction.groupBy({
    by: ["region"],
    where: { type: "REVENUE" },
    _sum: { amount: true },
  });

  res.json({
    regions: grouped.map((g) => ({ region: g.region || "Unknown", revenue: Number(g._sum.amount || 0) })),
  });
});

const list = asyncHandler(async (req, res) => {
  const page = Math.max(1, Number(req.query.page || 1));
  const pageSize = Math.min(Number(req.query.pageSize || 25), 100);
  const type = req.query.type === "EXPENSE" ? "EXPENSE" : "REVENUE";
  const where = buildWhere(req.query, type);

  const [items, total] = await Promise.all([
    prisma.transaction.findMany({
      where,
      orderBy: { date: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.transaction.count({ where }),
  ]);

  res.json({ items, total, page, pageSize });
});

const create = asyncHandler(async (req, res) => {
  const { type, amount, category, region, department, businessUnit, description, date, productId, customerId } =
    req.body;

  if (!type || !amount || !category || !date) {
    return res.status(400).json({ error: "type, amount, category, and date are required" });
  }

  const transaction = await prisma.transaction.create({
    data: {
      type,
      amount,
      category,
      region,
      department,
      businessUnit,
      description,
      date: new Date(date),
      productId: productId || null,
      customerId: customerId || null,
    },
  });

  res.status(201).json({ transaction });
});

module.exports = { getSummary, getTrend, getByRegion, list, create };
