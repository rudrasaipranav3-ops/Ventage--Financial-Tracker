// ============================================================================
// Bridges the Node API and the Python/Prophet forecasting microservice:
// pulls daily historical totals from Postgres, posts them to the Python
// service, and persists the returned forecast for audit/history purposes.
// ============================================================================

const axios = require("axios");
const env = require("../config/env");
const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const generateForecast = asyncHandler(async (req, res) => {
  const metric = req.body.metric || "revenue";
  const horizonDays = Number(req.body.horizonDays || 90);
  const txType = metric === "expenses" ? "EXPENSE" : "REVENUE";

  const history = await prisma.$queryRaw`
    SELECT date_trunc('day', date) AS ds, SUM(amount) AS y
    FROM transactions
    WHERE type = ${txType}
    GROUP BY 1
    ORDER BY 1 ASC;
  `;

  if (history.length < 5) {
    return res.status(400).json({ error: "Not enough historical data to forecast (need at least 5 points)" });
  }

  const payload = {
    history: history.map((row) => ({ ds: row.ds.toISOString().slice(0, 10), y: Number(row.y) })),
    horizon_days: horizonDays,
  };

  let forecastData;
  try {
    const response = await axios.post(`${env.FORECAST_SERVICE_URL}/forecast`, payload, { timeout: 20000 });
    forecastData = response.data;
  } catch (err) {
    const detail = err.response && err.response.data ? err.response.data : err.message;
    const wrapped = new Error("Forecast service request failed");
    wrapped.status = 502;
    wrapped.publicMessage = "The forecasting service is unavailable. Please try again shortly.";
    wrapped.detail = detail;
    throw wrapped;
  }

  const forecast = await prisma.forecast.create({
    data: {
      metric,
      horizonDays,
      modelVersion: forecastData.model_version || "prophet-v1",
      dataPoints: forecastData.forecast,
      createdById: req.user.id,
    },
  });

  res.json({ forecast });
});

const listForecasts = asyncHandler(async (req, res) => {
  const forecasts = await prisma.forecast.findMany({ orderBy: { generatedAt: "desc" }, take: 20 });
  res.json({ forecasts });
});

module.exports = { generateForecast, listForecasts };
