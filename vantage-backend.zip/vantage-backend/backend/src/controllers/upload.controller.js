// ============================================================================
// Ingests a CSV of transactions: parses it, drops rows missing required
// fields (date, amount, type), coerces types, and bulk-inserts the rest in
// a single transaction so a partial failure doesn't leave orphaned rows.
// ============================================================================

const Papa = require("papaparse");
const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const uploadFile = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });

  const text = req.file.buffer.toString("utf8");
  const parsed = Papa.parse(text, { header: true, dynamicTyping: true, skipEmptyLines: true });

  if (parsed.errors.length) {
    return res.status(400).json({ error: "Could not parse CSV", details: parsed.errors.slice(0, 5) });
  }

  const validRows = parsed.data.filter((r) => r.date && r.amount !== undefined && r.amount !== null && r.type);

  const created = await prisma.$transaction(
    validRows.map((r) =>
      prisma.transaction.create({
        data: {
          type: String(r.type).toUpperCase() === "EXPENSE" ? "EXPENSE" : "REVENUE",
          amount: Number(r.amount),
          currency: r.currency || "USD",
          category: r.category || "Uncategorized",
          region: r.region || null,
          department: r.department || null,
          date: new Date(r.date),
        },
      })
    )
  );

  const upload = await prisma.upload.create({
    data: {
      filename: req.file.originalname,
      rowCount: created.length,
      status: "processed",
      createdById: req.user.id,
    },
  });

  res.status(201).json({
    upload,
    rowsImported: created.length,
    rowsSkipped: parsed.data.length - validRows.length,
    columnsDetected: parsed.meta.fields,
  });
});

module.exports = { uploadFile };
