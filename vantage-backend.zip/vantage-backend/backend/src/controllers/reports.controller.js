// ============================================================================
// Streams generated PDF (PDFKit) and Excel (ExcelJS) exports directly to the
// response — nothing is written to disk, so there's no cleanup step and no
// risk of stale files accumulating on the server.
// ============================================================================

const PDFDocument = require("pdfkit");
const ExcelJS = require("exceljs");
const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

async function computeSummary() {
  const [revenueAgg, expenseAgg] = await Promise.all([
    prisma.transaction.aggregate({ where: { type: "REVENUE" }, _sum: { amount: true } }),
    prisma.transaction.aggregate({ where: { type: "EXPENSE" }, _sum: { amount: true } }),
  ]);
  const totalRevenue = Number(revenueAgg._sum.amount || 0);
  const totalExpenses = Number(expenseAgg._sum.amount || 0);
  const profit = totalRevenue - totalExpenses;
  return { totalRevenue, totalExpenses, profit, netMargin: totalRevenue === 0 ? 0 : (profit / totalRevenue) * 100 };
}

const exportPDF = asyncHandler(async (req, res) => {
  const summary = await computeSummary();

  // Log the export before streaming the response, so a logging failure
  // surfaces as a normal error response instead of corrupting an
  // already-started PDF stream.
  await prisma.report.create({
    data: { title: "Financial Summary PDF", type: "pdf", createdById: req.user.id },
  });

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", "attachment; filename=vantage-report.pdf");

  const doc = new PDFDocument({ margin: 50 });
  doc.pipe(res);

  doc.fontSize(22).text("Vantage Financial Report");
  doc.moveDown(0.3);
  doc.fontSize(10).fillColor("#666666").text(`Generated ${new Date().toLocaleString()}`);
  doc.moveDown(1.5);

  doc.fontSize(14).fillColor("#000000").text("Executive Summary");
  doc.moveDown(0.5);
  doc.fontSize(11);
  doc.text(`Total Revenue: $${summary.totalRevenue.toLocaleString()}`);
  doc.text(`Total Expenses: $${summary.totalExpenses.toLocaleString()}`);
  doc.text(`Net Profit: $${summary.profit.toLocaleString()}`);
  doc.text(`Net Margin: ${summary.netMargin.toFixed(1)}%`);

  doc.end();
});

const exportExcel = asyncHandler(async (req, res) => {
  const rows = await prisma.transaction.findMany({ orderBy: { date: "desc" }, take: 5000 });

  await prisma.report.create({
    data: { title: "Transaction Export XLSX", type: "excel", createdById: req.user.id },
  });

  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Vantage";
  const sheet = workbook.addWorksheet("Transactions");

  sheet.columns = [
    { header: "Date", key: "date", width: 14 },
    { header: "Type", key: "type", width: 12 },
    { header: "Category", key: "category", width: 20 },
    { header: "Region", key: "region", width: 16 },
    { header: "Amount", key: "amount", width: 14 },
  ];
  sheet.getRow(1).font = { bold: true };

  rows.forEach((r) => {
    sheet.addRow({
      date: r.date.toISOString().slice(0, 10),
      type: r.type,
      category: r.category,
      region: r.region,
      amount: Number(r.amount),
    });
  });

  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", "attachment; filename=vantage-export.xlsx");

  await workbook.xlsx.write(res);
  res.end();
});

module.exports = { exportPDF, exportExcel };
