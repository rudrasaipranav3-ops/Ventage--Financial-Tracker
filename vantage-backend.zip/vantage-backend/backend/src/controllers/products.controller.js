// ============================================================================
// Product performance analytics.
// ============================================================================

const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const topProducts = asyncHandler(async (req, res) => {
  const limit = Math.min(Number(req.query.limit || 10), 50);

  const grouped = await prisma.transaction.groupBy({
    by: ["productId"],
    where: { type: "REVENUE", productId: { not: null } },
    _sum: { amount: true },
    orderBy: { _sum: { amount: "desc" } },
    take: limit,
  });

  const productIds = grouped.map((g) => g.productId).filter(Boolean);
  const products = await prisma.product.findMany({ where: { id: { in: productIds } } });
  const byId = Object.fromEntries(products.map((p) => [p.id, p]));

  res.json({
    products: grouped.map((g) => ({
      product: byId[g.productId] || null,
      revenue: Number(g._sum.amount || 0),
    })),
  });
});

const list = asyncHandler(async (req, res) => {
  const products = await prisma.product.findMany({ orderBy: { name: "asc" } });
  res.json({ products });
});

const create = asyncHandler(async (req, res) => {
  const { name, sku, category, price } = req.body;
  if (!name || price === undefined) return res.status(400).json({ error: "name and price are required" });

  const product = await prisma.product.create({ data: { name, sku, category, price } });
  res.status(201).json({ product });
});

module.exports = { topProducts, list, create };
