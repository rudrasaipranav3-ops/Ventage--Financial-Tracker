// ============================================================================
// Admin-only user management: list users and change roles. Mounted behind
// requireRole("ADMIN") in routes/users.routes.js.
// ============================================================================

const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const VALID_ROLES = ["ADMIN", "MANAGER", "ANALYST", "VIEWER"];

const listUsers = asyncHandler(async (req, res) => {
  const users = await prisma.user.findMany({
    select: { id: true, email: true, name: true, role: true, createdAt: true, avatarUrl: true },
    orderBy: { createdAt: "desc" },
  });
  res.json({ users });
});

const updateRole = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { role } = req.body;

  if (!VALID_ROLES.includes(role)) {
    return res.status(400).json({ error: `role must be one of: ${VALID_ROLES.join(", ")}` });
  }

  const user = await prisma.user.update({ where: { id }, data: { role } });
  res.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role } });
});

module.exports = { listUsers, updateRole };
