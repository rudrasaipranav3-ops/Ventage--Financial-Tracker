// ============================================================================
// Customer analytics: segment breakdown, top customers by lifetime value,
// and churn rate. Full RFM scoring lives in the Python service
// (POST /analytics/rfm) since it needs pandas' quantile binning; this
// controller serves the lighter, pre-computed `segment` field for fast
// dashboard reads.
// ============================================================================

const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");

const listSegments = asyncHandler(async (req, res) => {
  const grouped = await prisma.customer.groupBy({
    by: ["segment"],
    _count: true,
    _sum: { lifetimeValue: true },
  });

  res.json({
    segments: grouped.map((g) => ({
      segment: g.segment || "Unclassified",
      count: g._count,
      totalLTV: Number(g._sum.lifetimeValue || 0),
    })),
  });
});

const topByLTV = asyncHandler(async (req, res) => {
  const limit = Math.min(Number(req.query.limit || 10), 50);
  const customers = await prisma.customer.findMany({
    orderBy: { lifetimeValue: "desc" },
    take: limit,
  });
  res.json({ customers });
});

const churnRate = asyncHandler(async (req, res) => {
  const [totalCustomers, churned] = await Promise.all([
    prisma.customer.count(),
    prisma.customer.count({ where: { churnedAt: { not: null } } }),
  ]);
  const rate = totalCustomers === 0 ? 0 : (churned / totalCustomers) * 100;
  res.json({ totalCustomers, churned, churnRatePct: +rate.toFixed(2) });
});

module.exports = { listSegments, topByLTV, churnRate };
