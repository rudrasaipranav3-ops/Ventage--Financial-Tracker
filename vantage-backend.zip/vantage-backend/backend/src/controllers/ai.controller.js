// ============================================================================
// AI Business Insights: a structured executive-report generator and a
// natural-language Q&A endpoint, both provider-agnostic via aiService. Every
// call is logged to AILog for auditing and cost tracking.
// ============================================================================

const prisma = require("../config/prisma");
const asyncHandler = require("../utils/asyncHandler");
const { generateInsight } = require("../services/aiService");

const REPORT_SYSTEM_PROMPT =
  "You are the AI analyst embedded in Vantage, a financial performance dashboard. " +
  "You will receive a JSON summary of a company's financial dataset. Respond with ONLY valid JSON " +
  "(no markdown fences, no preamble) matching exactly this shape: " +
  '{"healthScore": number 0-100, "summary": string, "insights": string[], "risks": string[], ' +
  '"opportunities": string[], "actionItems": string[], ' +
  '"swot": {"strengths": string[], "weaknesses": string[], "opportunities": string[], "threats": string[]}}. ' +
  "Ground every claim in the numbers provided. Be specific and concise.";

const CHAT_SYSTEM_PROMPT =
  "You are the AI analyst embedded in Vantage, a financial performance dashboard. " +
  "Answer the user's question about their data using ONLY the JSON dataset summary provided. " +
  "Be concise (2-4 sentences), cite specific numbers, and never invent data not present in the summary.";

const generateReport = asyncHandler(async (req, res) => {
  const { summary, provider } = req.body;
  if (!summary) return res.status(400).json({ error: "summary (dataset JSON) is required" });

  const raw = await generateInsight(JSON.stringify(summary), REPORT_SYSTEM_PROMPT, provider);

  await prisma.aILog.create({
    data: {
      provider: provider || "claude",
      prompt: JSON.stringify(summary).slice(0, 2000),
      response: raw.slice(0, 4000),
      createdById: req.user.id,
    },
  });

  let report;
  try {
    report = JSON.parse(raw.replace(/```json|```/g, "").trim());
  } catch (err) {
    return res.status(502).json({ error: "AI returned an unparseable report", raw });
  }

  res.json({ report });
});

const askQuestion = asyncHandler(async (req, res) => {
  const { question, context, provider } = req.body;
  if (!question || !context) return res.status(400).json({ error: "question and context are required" });

  const prompt = `DATA:\n${JSON.stringify(context)}\n\nQUESTION: ${question}`;
  const answer = await generateInsight(prompt, CHAT_SYSTEM_PROMPT, provider);

  await prisma.aILog.create({
    data: { provider: provider || "claude", prompt: question, response: answer.slice(0, 4000), createdById: req.user.id },
  });

  res.json({ answer });
});

module.exports = { generateReport, askQuestion };
