// ============================================================================
// Handles registration, email/password login, refresh-token rotation,
// logout, and the Google OAuth callback. Access tokens are short-lived JWTs;
// refresh tokens are persisted so they can be revoked individually.
// ============================================================================

const bcrypt = require("bcryptjs");
const prisma = require("../config/prisma");
const env = require("../config/env");
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require("../utils/jwt");
const asyncHandler = require("../utils/asyncHandler");

function sanitize(user) {
  const { passwordHash, ...rest } = user;
  return rest;
}

async function issueTokens(user) {
  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);
  const expiresAt = new Date(Date.now() + env.JWT_REFRESH_EXPIRES_IN_DAYS * 24 * 60 * 60 * 1000);
  await prisma.refreshToken.create({ data: { token: refreshToken, userId: user.id, expiresAt } });
  return { accessToken, refreshToken };
}

const register = asyncHandler(async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || !name) {
    return res.status(400).json({ error: "email, password, and name are required" });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters" });
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return res.status(409).json({ error: "An account with this email already exists" });

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await prisma.user.create({ data: { email, passwordHash, name, role: "VIEWER" } });

  const tokens = await issueTokens(user);
  res.status(201).json({ user: sanitize(user), ...tokens });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !user.passwordHash) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return res.status(401).json({ error: "Invalid email or password" });

  const tokens = await issueTokens(user);
  res.json({ user: sanitize(user), ...tokens });
});

const refresh = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: "refreshToken is required" });

  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired refresh token" });
  }

  const stored = await prisma.refreshToken.findUnique({ where: { token: refreshToken } });
  if (!stored || stored.expiresAt < new Date()) {
    return res.status(401).json({ error: "Refresh token expired or revoked" });
  }

  const user = await prisma.user.findUnique({ where: { id: payload.sub } });
  if (!user) return res.status(401).json({ error: "User no longer exists" });

  // Rotate: delete the used refresh token and issue a fresh pair.
  await prisma.refreshToken.delete({ where: { token: refreshToken } });
  const tokens = await issueTokens(user);
  res.json({ user: sanitize(user), ...tokens });
});

const logout = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    await prisma.refreshToken.deleteMany({ where: { token: refreshToken } });
  }
  res.status(204).send();
});

const me = asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user.id } });
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ user: sanitize(user) });
});

const googleCallback = asyncHandler(async (req, res) => {
  // passport.authenticate has already attached the User record to req.user.
  const tokens = await issueTokens(req.user);
  const redirectUrl =
    `${env.FRONTEND_URL}/oauth/callback` + `?accessToken=${tokens.accessToken}&refreshToken=${tokens.refreshToken}`;
  res.redirect(redirectUrl);
});

module.exports = { register, login, refresh, logout, me, googleCallback };
