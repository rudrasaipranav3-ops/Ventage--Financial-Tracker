// ============================================================================
// Minimal smoke test using Node's built-in test runner (node --test), so no
// extra test framework dependency is required. Extend with supertest-style
// HTTP assertions once a test database is wired into CI.
// ============================================================================

const test = require("node:test");
const assert = require("node:assert");

test("environment module exports required keys", () => {
  process.env.DATABASE_URL = process.env.DATABASE_URL || "postgresql://test:test@localhost:5432/test";
  const env = require("../src/config/env");
  assert.ok(env.PORT > 0);
  assert.ok(["development", "production", "test"].includes(env.NODE_ENV));
});
